import './App.css';
import { TextField,Stack,Button } from '@mui/material';

function App() {
  return (
    <div style={{height:'100vh'}} className='d-flex justify-content-center align-items-center w-100 bg-dark'>
      <div style={{width:'500px'}} className='bg-light p-5 rounded'>
        <h1>Simple Intrest App</h1>
        <p>Calculate yourbsimple Intrest</p>
        <div style={{height:'150px'}} className="interest-card w-100 bg-warning mt-5 d-flex justify-content-center align-items-center flex-column text-light shadow rounded">
          <h1>₹ {' '} 2000</h1>
          <p className='fw-bolder'>Total simple Intrest</p>
        </div>
        <form className='mt-5'>
          <div className='mb-3'>
          <TextField id="outlined-basic1" label="₹ Principle Amount" variant="outlined" className='w-100'/>
          </div>
          <div className='mb-3'>
          <TextField id="outlined-basic2" label="Rate of Intrest (p.a) %" variant="outlined" className='w-100'/>
          </div>
          <div className='mb-3'>
          <TextField id="outlined-basic3" label="Time Period(yr)" variant="outlined" className='w-100'/>
          </div>
          <Stack direction="row" spacing={2}>
              <Button variant="contained" style={{height:'70px',width:'200px'}}>CALCULATE</Button>
              <Button variant="outlined" style={{height:'70px',width:'200px'}}>RESET</Button>
          </Stack>
        </form>
      </div>
      
    </div>
  );
}

export default App;
